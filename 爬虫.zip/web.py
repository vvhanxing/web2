from requests_html import HTMLSession
def get_html_txt(url):
    session = HTMLSession()
    r = session.get(url)
    print(r.html.text)

url = 'https://cszg.mca.gov.cn/biz/ma/csmh/a/csmhaindex.html'
get_html_txt(url)